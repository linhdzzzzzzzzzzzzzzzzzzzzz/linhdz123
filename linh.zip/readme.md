node RAW-OMU.js <target> <time> <thread>
proxy only socks5 http/https ok nhé ?
build By An Vũ
